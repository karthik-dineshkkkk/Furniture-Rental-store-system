from tkinter import *
import pages
from pages import BackgroundPage

if __name__ == '__main__':
    root = Tk()
    BackgroundPage.BackgroundPage(root)